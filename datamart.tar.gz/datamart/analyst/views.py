#!/usr/bin/python
# _*_ coding:utf:8 _*_

from django.shortcuts import render, render_to_response, RequestContext
from django.http import HttpResponse, HttpResponseRedirect
from django.core.urlresolvers import reverse
# from django.views.decorators.csrf import csrf_project
from django.db.models import *
import csv
import json
from models import *
import datetime
import time
from django import http
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )



# Create your views here.
def order(request):
	return render(request, 'order.html')

def daily_summary(request):
    return render(request, 'daily_summary.html')

def daily_member(request):
    return render(request, 'daily_member.html')

def daily_product(request):
    return render(request, 'daily_product.html')

def signapi(request):
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    if prov == '全部':
        data = area_login.objects.filter(login_date__range=(begin, end)).values('login_date').annotate(sign_new=Sum('sign_new'),sign_total=Sum('sign_total')).order_by('login_date')
    elif city == '全部':
        data = area_login.objects.filter(login_date__range=(begin, end),province_name=prov).values('login_date').annotate(sign_new=Sum('sign_new'),sign_total=Sum('sign_total')).order_by('login_date')
    elif dist == '全部':
        data = area_login.objects.filter(login_date__range=(begin, end),city_name=city).values('login_date').annotate(sign_new=Sum('sign_new'),sign_total=Sum('sign_total')).order_by('login_date')
    else:
        data = area_login.objects.filter(login_date__range=(begin, end),zone_name=dist).values('login_date').annotate(sign_new=Sum('sign_new'),sign_total=Sum('sign_total')).order_by('login_date')
        
    test = {'status':0, 'fields':[]}
    val = {}
    for i in range(len(data)):
        val['login_date'] = str(data[i]['login_date'])
        val['sign_new'] = str(data[i]['sign_new'])
        val['sign_total'] = str(data[i]['sign_total'])
        test['fields'].insert(i,val)
        val = {}

    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")

def italy(request):
    return render(request, 'italy.html')

def download(request):    
    response = HttpResponse(content_type='text/csv')  
    response['Content-Disposition'] = 'attachment; filename=订单.csv'  
    writer = csv.writer(response)  
    writer.writerow(['日期/时间段','订单数','购买人数','实付金额','应付金额','优惠金额'])
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    temp = (end - begin).days
    if int(temp):
        if prov == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('create_date')
        elif city == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),province_name=prov,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('create_date')
        elif dist == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),city_name=city,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('create_date')
        else:
            data = father_order.objects.filter(create_date__range=(begin, end),zone_name=dist,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True)).order_by('create_date')
         
    else:
        if prov == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        elif city == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),province_name=prov,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        elif dist == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),city_name=city,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        else:
            data = father_order.objects.filter(create_date__range=(begin, end),zone_name=dist,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        
    if (int(temp)):
        for i in range(len(data)):
            writer.writerow([str(data[i]['create_date']), str(data[i]['order_number']), data[i]['member'], 
                str(data[i]['order_pay']), str(data[i]['order_cash']), str(data[i]['order_pay']-data[i]['order_cash'])])
    else:
        for i in range(len(data)):
            writer.writerow([str(data[i]['time_name']), str(data[i]['order_number']), data[i]['member'], 
                str(data[i]['order_pay']), str(data[i]['order_cash']), str(data[i]['order_pay']-data[i]['order_cash'])])
    return response

def orderapi(request):
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    temp = (end - begin).days
    if int(temp):
        if prov == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('create_date')
        elif city == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),province_name=prov,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('create_date')
        elif dist == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),city_name=city,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('create_date')
        else:
            data = father_order.objects.filter(create_date__range=(begin, end),zone_name=dist,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('create_date').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('create_date')
         
    else:
        if prov == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        elif city == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),province_name=prov,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        elif dist == '全部':
            data = father_order.objects.filter(create_date__range=(begin, end),city_name=city,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        else:
            data = father_order.objects.filter(create_date__range=(begin, end),zone_name=dist,order_status__in=[1,2],
                ship_status__in=[0,1,2,5,6]).values('time_name').annotate(order_cash=Sum('order_cash'),
                order_pay=Sum('order_pay'),member=Count('member_license',distinct=True),order_number=Count('order_code')).order_by('time_name')
        
    if (int(temp)):
        test = {'status':0, 'fields':[]}
        val = {}
        for i in range(len(data)):
            val['create_date'] = str(data[i]['create_date'])
            val['member'] = data[i]['member']
            val['order_cash'] = str(data[i]['order_cash'])
            val['order_pay'] = str(data[i]['order_pay'])
            val['order_number'] = str(data[i]['order_number'])
            test['fields'].insert(i,val)
            val = {}
    else:
        test = {'status':0, 'fields':[]}
        val = {}
        for i in range(len(data)):
            val['create_date'] = data[i]['time_name']
            val['member'] = data[i]['member']
            val['order_cash'] = str(data[i]['order_cash'])
            val['order_pay'] = str(data[i]['order_pay'])
            val['order_number'] = str(data[i]['order_number'])
            test['fields'].insert(i,val)
            val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        passwd = request.POST['passwd']

        data = user.objects.filter(username__exact=username, password__exact=passwd).values()

        if len(data):
            nickname = data[0]['nickname']
            nickname = nickname.encode('gb2312')
            response = http.HttpResponseRedirect(reverse('analyst.views.daily_summary'))
            #response = http.HttpResponseRedirect('http://192.168.4.3:8083/summary/daily/report/')
            response.set_cookie('nickname', nickname, 3600*24*365)
            return response
        else:
            return http.HttpResponseRedirect('http://192.168.4.3:8083/login/')
    else:
        return render(request, 'denglu.html')

def order_api(request):
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    temp = (end - begin).days

    if int(temp):
        if prov == '全部':
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin, end),dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_date__date_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_date__date_name')
        elif city == '全部':
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__province_name=prov,dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_date__date_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_date__date_name')
        elif dist == '全部':
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__city_name=city,dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_date__date_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_date__date_name')
        else:
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__zone_name=dist,dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_date__date_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_date__date_name')
         
    else:
        if prov == '全部':
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__member_flag=0,dim_order_status__status_value__in=[1,2],dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_time__hour_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_time__hour_name')
        elif city == '全部':
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__member_flag=0,dim_member__province_name=prov,dim_order_status__status_value__in=[1,2],dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_time__hour_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_time__hour_name')
        elif dist == '全部':
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__member_flag=0,dim_member__city_name=city,dim_order_status__status_value__in=[1,2],dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_time__hour_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_time__hour_name')
        else:
            data = fact_father_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__member_flag=0,dim_member__zone_name=dist,dim_order_status__status_value__in=[1,2],dim_shipping_status__status_value__in=[0,1,2,5,6]).values('dim_time__hour_name').annotate(order_total=Sum('order_total'),order_promotion=Sum('order_promotion'),order_cash=Sum('order_cash'),order_member=Count('dim_member__member_code',distinct=True),order_number=Count('order_id')).order_by('dim_time__hour_name')

    if (int(temp)):
        test = {'status':0, 'fields':[]}
        val = {}
        for i in range(len(data)):
            val['date_time_name'] = str(data[i]['dim_date__date_name'])
            val['order_total'] = str(data[i]['order_total'])
            val['order_promotion'] = str(data[i]['order_promotion'])
            val['order_cash'] = str(data[i]['order_cash'])
            val['order_member'] = data[i]['order_member']
            val['order_number'] = str(data[i]['order_number'])
            test['fields'].insert(i,val)
            val = {}
    else:
        test = {'status':0, 'fields':[]}
        val = {}
        for i in range(len(data)):
            val['date_time_name'] = data[i]['dim_time__hour_name']
            val['order_total'] = str(data[i]['order_total'])
            val['order_promotion'] = str(data[i]['order_promotion'])
            val['order_cash'] = str(data[i]['order_cash'])
            val['order_member'] = data[i]['order_member']
            val['order_number'] = str(data[i]['order_number'])
            test['fields'].insert(i,val)
            val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")


def summary_daily_report_api(request):
    date_name = (datetime.datetime.now()-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    data = city_data.objects.filter(date_name=date_name).values('city_name','order_first_people','order_all_people',
        'sale_number','sale_cash','date_name')
    test = {'status':0, 'fields':[]}
    val = {}
    for i in range(len(data)):
        val['city_name'] = data[i]['city_name']
        val['sign_new'] = str(data[i]['order_first_people'])
        val['order_all_people'] = str(data[i]['order_all_people'])
        val['sale_number'] = str(data[i]['sale_number'])
        val['sale_cash'] = str(data[i]['sale_cash'])
        val['date_name'] = str(data[i]['date_name'])
        test['fields'].insert(i,val)
        val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")


def product_api(request):
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    temp = (end - begin).days

    if prov == '全部':
        data = fact_son_order.objects.filter(dim_date__date_name__range=(begin, end),dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6],dim_isgift=1).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_quantity'),sale_product_member=Count('dim_member__member_code',distinct=True),sale_product_cash=Sum('sale_cash')).order_by('-sale_product_number')
    elif city == '全部':
        data = fact_son_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__province_name=prov,dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6],dim_isgift=1).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_quantity'),sale_product_member=Count('dim_member__member_code',distinct=True),sale_product_cash=Sum('sale_cash')).order_by('-sale_product_number')
    elif dist == '全部':
        data = fact_son_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__city_name=city,dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6],dim_isgift=1).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_quantity'),sale_product_member=Count('dim_member__member_code',distinct=True),sale_product_cash=Sum('sale_cash')).order_by('-sale_product_number')
    else:
        data = fact_son_order.objects.filter(dim_date__date_name__range=(begin,end),dim_member__zone_name=dist,dim_order_status__status_value__in=[1,2],dim_member__member_flag=0,dim_shipping_status__status_value__in=[0,1,2,5,6],dim_isgift=1).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_quantity'),sale_product_member=Count('dim_member__member_code',distinct=True),sale_product_cash=Sum('sale_cash')).order_by('-sale_product_number')
         
    test = {'status':0, 'fields':[]}
    val = {}
    for i in range(len(data)):
        val['product_name'] = data[i]['dim_product__product_name']
        val['sale_product_number'] = str(data[i]['sale_product_number'])
        val['sale_product_member'] = str(data[i]['sale_product_member'])
        val['sale_product_cash'] = str(data[i]['sale_product_cash'])
        test['fields'].insert(i,val)
        val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")


def product_daily_api(request):
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    temp = (end - begin).days

    if prov == '全部':
        data = fact_city_data.objects.filter(dim_date__date_name__range=(begin, end)).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
    elif city == '全部':
        data = fact_city_data.objects.filter(dim_date__date_name__range=(begin,end),dim_area__province_name=prov).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
    elif dist == '全部':
        data = fact_son_order.objects.filter(dim_date__date_name__range=(begin,end),dim_area__city_name=city).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
    else:
        data = fact_son_order.objects.filter(dim_date__date_name__range=(begin,end),dim_area__zone_name=dist).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
         
    test = {'status':0, 'fields':[]}
    val = {}
    for i in range(len(data)):
        val['product_name'] = data[i]['dim_product__product_name']
        val['sale_product_number'] = str(data[i]['sale_product_number'])
        val['sale_product_member'] = str(data[i]['sale_product_member'])
        val['sale_product_cash'] = str(data[i]['sale_product_cash'])
        test['fields'].insert(i,val)
        val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")

def summary_product_daily_api(request):
    date_name = (datetime.datetime.now()-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    data = fact_city_data.objects.filter(dim_date__date_name=date_name).values('dim_area__city_name','dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')

    test = {'status':0, 'fields':[]}
    val = {}
    for i in range(len(data)):
        val['product_name'] = data[i]['dim_product__product_name']
        val['city_name'] = data[i]['dim_area__city_name']
        val['sale_product_number'] = str(data[i]['sale_product_number'])
        val['sale_product_member'] = str(data[i]['sale_product_member'])
        val['sale_product_cash'] = str(data[i]['sale_product_cash'])
        test['fields'].insert(i,val)
        val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")

def member_daily_api(request):
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    temp = (end - begin).days

    if prov == '全部':
        data = fact_member_sign.objects.filter(dim_date__date_name__range=(begin, end)).values('dim_date__date_name').annotate(sign_new=Sum('sign_new'),sign_total=Sum('sign_total')).order_by('dim_date__date_name')
    elif city == '全部':
        data = fact_member_sign.objects.filter(dim_date__date_name__range=(begin,end),dim_area__province_name=prov).values('dim_date__date_name').annotate(sign_new=Sum('sign_new'),sign_total=Sum('sign_total')).order_by('dim_date__date_name')
    elif dist == '全部':
        data = fact_member_sign.objects.filter(dim_date__date_name__range=(begin,end),dim_area__city_name=city).values('dim_date__date_name').annotate(sign_new=Sum('sign_new'),sign_total=Sum('sign_total')).order_by('dim_date__date_name')
    else:
        data = fact_member_sign.objects.filter(dim_date__date_name__range=(begin,end),dim_area__zone_name=dist).values('dim_date__date_name','sign_new','sign_total').order_by('dim_date__date_name')
         
    test = {'status':0, 'fields':[]}
    val = {}
    for i in range(len(data)):
        val['date_name'] = str(data[i]['dim_date__date_name'])
        val['sign_new'] = str(data[i]['sign_new'])
        val['sign_total'] = str(data[i]['sign_total'])
        test['fields'].insert(i,val)
        val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")


def product_daily_api(request):
    begin = request.GET.get('begin')
    begin = datetime.datetime.strptime(begin,'%Y/%m/%d')
    end = request.GET.get('end')
    end = datetime.datetime.strptime(end,'%Y/%m/%d')
    prov = request.GET.get('prov')
    city = request.GET.get('city')
    dist = request.GET.get('dist')
    temp = (end - begin).days

    if prov == '全部':
        data = fact_city_data.objects.filter(dim_date__date_name__range=(begin, end)).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
    elif city == '全部':
        data = fact_city_data.objects.filter(dim_date__date_name__range=(begin,end),dim_area__province_name=prov).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
    elif dist == '全部':
        data = fact_city_data.objects.filter(dim_date__date_name__range=(begin,end),dim_area__city_name=city).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
    else:
        data = fact_city_data.objects.filter(dim_date__date_name__range=(begin,end),dim_area__zone_name=dist).values('dim_product__product_name').annotate(sale_product_number=Sum('sale_product_number'),sale_product_member=Sum('sale_product_member'),sale_product_cash=Sum('sale_product_cash')).order_by('-sale_product_number')
         
    test = {'status':0, 'fields':[]}
    val = {}
    for i in range(len(data)):
        val['date_name'] = str(data[i]['dim_product__product_name'])
        val['sale_product_number'] = str(data[i]['sale_product_number'])
        val['sale_product_member'] = str(data[i]['sale_product_member'])
        val['sale_product_cash'] = str(data[i]['sale_product_cash'])
        test['fields'].insert(i,val)
        val = {}
    data = json.dumps(test)
    return HttpResponse(data, content_type="application/json")