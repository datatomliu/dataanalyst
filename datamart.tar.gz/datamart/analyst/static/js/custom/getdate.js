$(document).ready(function() {
    $('.applyBtn').click(function() {
        var test = $('.daterangepicker_start_input input').val();
        var test1 = $('.daterangepicker_end_input input').val();
        alert(test);
        alert(test1);
    });
});

// $(document).ready(function() {
//     $('#search_pagination').append("<li><a href='/index/'><i class='fa-angle-left'></i>上一页</a></li>");
//     for (var i = 1; i < 11; i++) {
//         $('#search_pagination').append("<li><a href='/index/'>" + i + "</a></li>");
//     }
//     $('#search_pagination').append("<li><a href='/index/'>下一页<i class='fa-angle-right'></i></a></li>");
// });

$(document).ready(function() {
    $('#search_pagination').on('click', 'li', function() {
        var curpage = $(this).text();
        alert(curpage);
        $(this).siblings().remove();
        $(this).remove();
        for (var i = 0; i < Math.floor(10 * Math.random())+1; i++) {
            $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
        };
        return false;
    });
});

$(document).ready(function() {
    $('.prov').change(function() {
        var checkText = $(".prov").find("option:selected").text();
        alert(checkText);
    });
});

// function pagination(curpage,totalpage){
// 	var temp;
// 	if(curpage < 5){

// 	}
// 	else if(curpage > (totalpage - 5)){

// 	}
// 	else{
// 		$('#search_pagination li').empty();
// 		$('#search_pagination').append("<li><a href="#"><i class="fa-angle-left"></i>上一页</a></li>");
// 		for(var i=curpage-6;i++;i<curpage+4){
// 			$('#search_pagination').append("<li><a href='#''>" + i + "</a></li>");
// 		}
// 		$('#search_pagination').append("<li><a href='#'>下一页<i class="fa-angle-right"></i></a></li>");
// 	}
// };

$(function() {
    $('#linechart').highcharts({
        chart: {
            type: 'areaspline'
        },
        title: {
            text: 'Average fruit consumption during one week'
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            x: 150,
            y: 100,
            floating: true,
            borderWidth: 1,
            backgroundColor: '#FFFFFF'
        },
        xAxis: {
            categories: [
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
                'Sunday'
            ],
            plotBands: [{ // visualize the weekend
                from: 4.5,
                to: 6.5,
                color: 'rgba(68, 170, 213, .2)'
            }]
        },
        yAxis: {
            title: {
                text: 'Fruit units'
            }
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: [{
            name: 'John',
            data: [3, 4, 3, 5, 4, 10, 12]
        }, {
            name: 'Jane',
            data: [1, 3, 4, 3, 3, 5, 4]
        }]
    });
});
