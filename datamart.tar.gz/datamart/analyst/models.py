from django.db import models

# Create your models here.

class user(models.Model):
	username = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	nickname = models.CharField(max_length=50)
	updatetime = models.DateTimeField(auto_now=True)

	class Meta:
		db_table = 'user'


class dim_time(models.Model):
    time_name = models.TimeField()
    hour_name = models.SmallIntegerField()
    minute_name = models.SmallIntegerField()
    second_name = models.SmallIntegerField()
    time_interval = models.CharField(max_length=20)
    time_type = models.CharField(max_length=4)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_time'


class dim_date(models.Model):
    date_name = models.DateField()
    full_name = models.IntegerField()
    year_name = models.SmallIntegerField()
    year_china_name = models.CharField(max_length=50)
    quarter_name = models.SmallIntegerField()
    quarter_china_name = models.CharField(max_length=50)
    month_name = models.SmallIntegerField()
    month_china_name = models.CharField(max_length=50)
    week_name = models.SmallIntegerField()
    week_china_name = models.CharField(max_length=50)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_date'


class dim_order_status(models.Model):
    status_value = models.SmallIntegerField()
    status_name = models.CharField(max_length=50)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_order_status'

class dim_shipping_status(models.Model):
    status_value = models.SmallIntegerField()
    status_name = models.CharField(max_length=50)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_shipping_status'

class dim_shipping_method(models.Model):
    method_value = models.SmallIntegerField()
    method_name = models.CharField(max_length=50)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_shipping_method'

class dim_member(models.Model):
    member_code = models.CharField(max_length=40)
    member_name = models.CharField(max_length=128)
    shop_name = models.CharField(max_length=128)
    address_name = models.CharField(max_length=256)
    province_name = models.CharField(max_length=128)
    province_code = models.SmallIntegerField()
    city_name = models.CharField(max_length=128)
    city_code = models.SmallIntegerField()
    zone_name = models.CharField(max_length=128)
    zone_code = models.SmallIntegerField()
    street_name = models.CharField(max_length=128)
    street_code = models.SmallIntegerField()
    member_flag = models.SmallIntegerField(default=0)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_member'

class dim_channel(models.Model):
    channel_value = models.SmallIntegerField()
    channel_name = models.CharField(max_length=50)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_channel'

class dim_shipping_address(models.Model):
    address_name = models.CharField(max_length=128)
    province_name = models.CharField(max_length=128)
    province_code = models.SmallIntegerField()
    city_name = models.CharField(max_length=128)
    city_code = models.SmallIntegerField()
    zone_name = models.CharField(max_length=128)
    zone_code = models.SmallIntegerField()
    street_name = models.CharField(max_length=128)
    street_code = models.SmallIntegerField()
    detail_name = models.CharField(max_length=128)
    address_longitude = models.DecimalField(max_digits=16, decimal_places=12, blank=True, null=True)
    address_latitude = models.DecimalField(max_digits=16, decimal_places=12, blank=True, null=True)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_shipping_address'

class fact_father_order(models.Model):
    dim_date = models.ForeignKey('dim_date', null=True, db_column='dim_date')
    dim_time = models.ForeignKey('dim_time', null=True, db_column='dim_time')
    dim_order_status = models.ForeignKey('dim_order_status', null=True, db_column='dim_order_status')
    dim_shipping_status = models.ForeignKey('dim_shipping_status', null=True, db_column='dim_shipping_status')
    dim_shipping_method = models.ForeignKey('dim_shipping_method', null=True, db_column='dim_shipping_method')
    dim_member = models.ForeignKey('dim_member', null=True, db_column='dim_member')
    dim_channel = models.ForeignKey('dim_channel', null=True, db_column='dim_channel')
    dim_shipping_address = models.ForeignKey('dim_shipping_address', null=True, db_column='dim_shipping_address')
    order_id = models.CharField(max_length=30)
    order_total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    order_promotion = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    order_cash = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'fact_father_order'

class fact_son_order(models.Model):
    dim_date = models.ForeignKey('dim_date', null=True, db_column='dim_date')
    dim_time = models.ForeignKey('dim_time', null=True, db_column='dim_time')
    dim_order_status = models.ForeignKey('dim_order_status', null=True, db_column='dim_order_status')
    dim_shipping_status = models.ForeignKey('dim_shipping_status', null=True, db_column='dim_shipping_status')
    dim_shipping_method = models.ForeignKey('dim_shipping_method', null=True, db_column='dim_shipping_method')
    dim_member = models.ForeignKey('dim_member', null=True, db_column='dim_member')
    dim_channel = models.ForeignKey('dim_channel', null=True, db_column='dim_channel')
    dim_product = models.ForeignKey('dim_product', null=True, db_column='dim_product')
    dim_isgift = models.ForeignKey('dim_isgift', null=True, db_column='dim_isgift')
    son_order_id = models.CharField(max_length=30)
    father_order_id = models.CharField(max_length=30)
    sale_quantity = models.IntegerField(default=0)
    product_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    promotion_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sale_total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sale_promotion = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sale_cash = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'fact_son_order'

class dim_isgift(models.Model):
    isgift_value = models.SmallIntegerField()
    isgift_name = models.CharField(max_length=50)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_isgift'

class dim_product(models.Model):
    product_code = models.IntegerField()
    product_sn = models.BigIntegerField()
    full_name = models.CharField(max_length=256)
    product_name = models.CharField(max_length=256)
    sale_factor = models.SmallIntegerField()
    sale_unit = models.CharField(max_length=50)
    unit_quantity = models.SmallIntegerField()
    unit_description = models.CharField(max_length=50)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_product'

class dim_area(models.Model):
    detail_name = models.CharField(max_length=128)
    detail_code = models.SmallIntegerField()
    province_name = models.CharField(max_length=128)
    province_code = models.SmallIntegerField()
    city_name = models.CharField(max_length=128)
    city_code = models.SmallIntegerField()
    zone_name = models.CharField(max_length=128)
    zone_code = models.SmallIntegerField()
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'dim_area'

class fact_member_sign(models.Model):
    dim_date = models.ForeignKey('dim_date', null=True, db_column='dim_date')
    dim_area = models.ForeignKey('dim_area', null=True, db_column='dim_area')
    sign_new = models.IntegerField(default=0)
    sign_total = models.IntegerField(default=0)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'fact_member_sign'


class city_data(models.Model):
    date_name = models.DateField()
    city_name = models.CharField(max_length=128)
    city_code = models.SmallIntegerField()
    sale_number = models.SmallIntegerField()
    sale_cash = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    order_people = models.SmallIntegerField()
    sign_new = models.IntegerField()
    order_all_people = models.IntegerField()
    order_first_people = models.IntegerField()
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'city_data'

class fact_city_data(models.Model):
    dim_date = models.ForeignKey('dim_date', null=True, db_column='dim_date')
    dim_area = models.ForeignKey('dim_area', null=True, db_column='dim_area')
    dim_product = models.ForeignKey('dim_product', null=True, db_column='dim_product')
    sale_product_number = models.IntegerField()
    sale_product_member = models.IntegerField()
    sale_product_cash = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    updatetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'fact_city_data'