$(document).ready(function() {
    operation();
});

function operation() {
	$.getJSON("/dash/depart/operation/", function(data) {
		for (var i = 0; i < data.fields.length; i++) {
			if (data.fields[i].city_code == '853') {
				$("#operate_sale_suzhou").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#old_sale_suzhou").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#operate_order_suzhou").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#operate_repeat_suzhou").text((data.fields[i].repeat_rate * 100).toFixed(2) + '%');
				$("#operate_promotion_suzhou").text((data.fields[i].promotion_rate * 100).toFixed(2) + '%');
				$("#caigou_sku_suzhou").text((data.fields[i].product_rate * 100).toFixed(2) + '%');
				$("#caigou_sale_suzhou").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_sale_suzhou").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_order_suzhou").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#login_member_suzhou").text((data.fields[i].login_number));
				$("#old_wakeup_suzhou").text((data.fields[i].wakeup_member));
				$("#old_new_suzhou").text((data.fields[i].new_member));
				$("#market_mobile_suzhou").text((data.fields[i].mobile_member));
				$("#market_login_suzhou").text((data.fields[i].login_number));
				reapt_rate = data.fields[i].repeat_rate * 100 ;

			} else if (data.fields[i].city_code == '811') {
				$("#operate_sale_nanjing").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#operate_order_nanjing").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#operate_repeat_nanjing").text((data.fields[i].repeat_rate * 100).toFixed(2) + '%');
				$("#operate_promotion_nanjing").text((data.fields[i].promotion_rate * 100).toFixed(2) + '%');
				$("#caigou_sku_nanjing").text((data.fields[i].product_rate * 100).toFixed(2) + '%');
				$("#caigou_sale_nanjing").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_sale_nanjing").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_order_nanjing").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#old_sale_nanjing").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#login_member_nanjing").text((data.fields[i].login_number));
				$("#old_wakeup_nanjing").text((data.fields[i].wakeup_member));
				$("#old_new_nanjing").text((data.fields[i].new_member));
				$("#market_mobile_nanjing").text((data.fields[i].mobile_member));
				$("#market_login_nanjing").text((data.fields[i].login_number));
			} else if (data.fields[i].city_code == '965') {
				$("#operate_sale_jiaxing").text((data.fields[i].sales/ 10000).toFixed(2) + '万');
				$("#operate_order_jiaxing").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#operate_repeat_jiaxing").text((data.fields[i].repeat_rate * 100).toFixed(2) + '%');
				$("#operate_promotion_jiaxing").text((data.fields[i].promotion_rate * 100).toFixed(2) + '%');
				$("#caigou_sku_jiaxing").text((data.fields[i].product_rate * 100).toFixed(2) + '%');
				$("#caigou_sale_jiaxing").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_sale_jiaxing").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_order_jiaxing").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#old_sale_jiaxing").text((data.fields[i].sales/ 10000).toFixed(2) + '万');
				$("#login_member_jiaxing").text((data.fields[i].login_number));
				$("#old_wakeup_jiaxing").text((data.fields[i].wakeup_member));
				$("#old_new_jiaxing").text((data.fields[i].new_member));
				$("#market_mobile_jiaxing").text((data.fields[i].mobile_member));
				$("#market_login_jiaxing").text((data.fields[i].login_number));
			} else {
				$("#operate_sale_hangzhou").text((data.fields[i].sales/ 10000).toFixed(2) + '万');
				$("#operate_order_hangzhou").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#operate_repeat_hangzhou").text((data.fields[i].repeat_rate * 100).toFixed(2) + '%');
				$("#operate_promotion_hangzhou").text((data.fields[i].promotion_rate * 100).toFixed(2) + '%');
				$("#caigou_sku_hangzhou").text((data.fields[i].product_rate * 100).toFixed(2) + '%');
				$("#caigou_sale_hangzhou").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_login_hangzhou").text((data.fields[i].login_number));
				$("#market_sale_hangzhou").text((data.fields[i].sales / 10000).toFixed(2) + '万');
				$("#market_order_hangzhou").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
				$("#market_mobile_hangzhou").text((data.fields[i].mobile_member));
				$("#new_mobile").text((data.fields[i].mobile_member));
				$("#new_login").text((data.fields[i].login_number));
				$("#new_order").text((data.fields[i].order_rate * 100).toFixed(2) + '%');
			};
		};
		var operate_sale = parseInt(data.fields[0].sales) + parseInt(data.fields[1].sales) + parseInt(data.fields[2].sales) + parseInt(data.fields[3].sales);
		var old_operate_sale = parseInt(data.fields[0].sales) + parseInt(data.fields[1].sales) + parseInt(data.fields[2].sales);
		var operate_promotion = parseInt(data.fields[0].promotion) + parseInt(data.fields[1].promotion) + parseInt(data.fields[2].promotion);
		$("#operate_sale").text((operate_sale / 10000).toFixed(2) + '万');
		$("#caigou_sale").text((operate_sale / 10000).toFixed(2) + '万');
		$("#market_sale").text((operate_sale / 10000).toFixed(2) + '万');
		$("#old_sale").text((old_operate_sale / 10000).toFixed(2) + '万');
		var login_member = parseInt(data.fields[0].login_member) + parseInt(data.fields[1].login_member) + parseInt(data.fields[2].login_member);
		var order_member = parseInt(data.fields[0].order_member) + parseInt(data.fields[1].order_member) + parseInt(data.fields[2].order_member);
		var wakeup_member = parseInt(data.fields[0].wakeup_member) + parseInt(data.fields[1].wakeup_member) + parseInt(data.fields[2].wakeup_member);
		var new_member = parseInt(data.fields[0].new_member) + parseInt(data.fields[1].new_member) + parseInt(data.fields[2].new_member);
		var mobile_member = parseInt(data.fields[0].mobile_member) + parseInt(data.fields[1].mobile_member) + parseInt(data.fields[2].mobile_member) + parseInt(data.fields[3].mobile_member);
		var market_login = parseInt(data.fields[0].login_number) + parseInt(data.fields[1].login_number) + parseInt(data.fields[2].login_number) + parseInt(data.fields[3].login_number);
		var old_login = parseInt(data.fields[0].login_number) + parseInt(data.fields[1].login_number) + parseInt(data.fields[2].login_number);
		$("#login_member").text(old_login);
		$("#old_wakeup").text(wakeup_member);
		$("#old_new").text(new_member);
		$("#market_login").text(market_login);
		$("#market_mobile").text(mobile_member);
		$("#operate_order").text(((order_member/login_member)*100).toFixed(2) + '%');
		$("#market_order").text(((order_member/login_member)*100).toFixed(2) + '%');
		var temp = data.fields[0].repeat_rate * 100 * 0.4 + data.fields[1].repeat_rate * 100 * 0.3 + data.fields[2].repeat_rate * 100 * 0.3;
		$("#operate_repeat").text(temp.toFixed(2) + '%');
		$("#operate_promotion").text((operate_promotion/operate_sale * 100).toFixed(2) + '%');
	});
}