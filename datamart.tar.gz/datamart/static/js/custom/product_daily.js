$(document).ready(function() {
    $('.applyBtn').click(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
});


$(document).ready(function() {
    $('#main_menu_summary_detail li:eq(' + 3 + ')').addClass('active');
    var startdate = moment().format("YYYY/MM/DD");
    $('#xsm_datersange').text(startdate + ' - ' + startdate);
    getdata(startdate, startdate, '全部', '', '');
    // alert(parseInt(Date.parse(startdate)-Date.parse(startdate))/(1000*60*60*24));
});

$(document).ready(function() {
    $('#xsm_range_filter').on('click', 'li', function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        // alert(moment(Date.parse('2016-01-03')).add('days',2).format('YYYY/MM/DD'));
        // alert(parseInt(Date.parse(end)-Date.parse(begin))/(1000*60*60*24));
        getdata(begin, end, prov, city, dist);
    });
});



$(document).ready(function() {
    $('.prov').change(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
    $('.city').change(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
    $('.dist').change(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var dist = $(".dist").find("option:selected").text();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
});

function clickpagination(curpage, totalpage) {
    if (totalpage > 10) {
        if (curpage > 6) {
            if (curpage == totalpage) {
                $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
                for (var i = (curpage - 9); i < (totalpage + 1); i++) {
                    $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
                }
                $('#search_pagination li:eq(' + 10 + ')').addClass('active');
            } else if (curpage > (totalpage - 5)) {
                $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
                for (var i = (totalpage - 9); i < (totalpage + 1); i++) {
                    $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
                }
                $('#search_pagination li:eq(' + (10 - totalpage + curpage) + ')').addClass('active');
            } else {
                $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
                for (var i = (curpage - 5); i < (curpage + 5); i++) {
                    $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
                }
                $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
                $('#search_pagination li:eq(' + 6 + ')').addClass('active');
            }
        } else {
            $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
            for (var i = 1; i < 11; i++) {
                $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
            }
            $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
            $('#search_pagination li:eq(' + curpage + ')').addClass('active');

        }
    } else if ((totalpage > 1) && (totalpage < 11)) {
        if (curpage == totalpage) {
            $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
            for (var i = 1; i < (totalpage + 1); i++) {
                $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
            }
            $('#search_pagination li:eq(' + curpage + ')').addClass('active');
        } else {
            $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
            for (var i = 1; i < (totalpage + 1); i++) {
                $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
            }
            $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
            $('#search_pagination li:eq(' + curpage + ')').addClass('active');
        }
    } else {
        $('#search_pagination').append("<li><a href='#'>" + 1 + "</a></li>");
        $('#search_pagination li:eq(' + 0 + ')').addClass('active');
    }
};

function pagination(page) {
    if (page == 1) {
        $('#search_pagination').append("<li><a href='#'>" + 1 + "</a></li>");
        $('#search_pagination li:eq(' + 0 + ')').addClass('active');
    } else if (page > 10) {
        $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
        for (var i = 1; i < 11; i++) {
            $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
        }
        $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
        $('#search_pagination li:eq(' + 1 + ')').addClass('active');
    } else if ((page > 1) && (page < 11)) {
        $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
        for (var i = 1; i < (page + 1); i++) {
            $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
        }
        $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
        $('#search_pagination li:eq(' + 1 + ')').addClass('active');
    }

};

function getchart(cate, data1) {
    $('#linechart').highcharts({
        chart: {
            type: 'areaspline'
        },
        title: {
            text: false
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            x: 150,
            y: 100,
            floating: true,
            borderWidth: 1,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        xAxis: {
            categories: cate,
        },
        yAxis: {
            title: {
                text: 'TOP20商品'
            }
        },
        tooltip: {
            shared: true,
            valueSuffix: ''
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: [{
            name: '销售数量',
            data: data1
        }]
    });
}

function getdata(begin, end, prov, city, dist) {
    var product_name_chart = new Array();
    var sale_product_number_chart = new Array();
    var sale_product_member_chart = new Array();
    var sale_product_cash_chart = new Array();

    var product_name = new Array();
    var sale_product_number = new Array();
    var sale_product_member = new Array();
    var sale_product_cash = new Array();

    // var tempdate = parseInt(Date.parse(end) - Date.parse(begin)) / (1000 * 60 * 60 * 24);

    // for (var i = 0; i < tempdate + 1; i++) {
    //     date_name_chart.push(moment(Date.parse(begin)).add('days', i).format('YYYY/MM/DD'));
    //     sign_new_chart.push(0);
    //     sign_total_chart.push(0);
    // }

    $.getJSON("/api/product/daily/", {
        'begin': begin,
        'end': end,
        'prov': prov,
        'city': city,
        'dist': dist
    }, function(data) {

        $("#thead_xsm th:eq(1)").html('日期');
        for (var i = 0; i < data.fields.length; i++) {
            // alert($.inArray(Date.parse(data.fields[i].create_date),create_name));
            // var temp = $.inArray(moment(Date.parse(data.fields[i].date_name)).format('YYYY/MM/DD'), date_name_chart);
            // if (temp > -1) {
            //     date_name_chart[temp] = parseFloat(data.fields[i].date_name);
            //     sign_total_chart[temp] = parseFloat(data.fields[i].sign_total);
            //     sign_new_chart[temp] = parseFloat(data.fields[i].sign_new);
            // }
            product_name[i] = data.fields[i].product_name;
            sale_product_number[i] = parseInt(data.fields[i].sale_product_number);
            sale_product_member[i] = parseInt(data.fields[i].sale_product_member);
            sale_product_cash[i] = parseInt(data.fields[i].sale_product_cash);
        };
        if (product_name.length > 20) {
            for (var i = 0; i < 20; i++) {
                product_name_chart.push(product_name[i]);
                sale_product_number_chart.push(sale_product_number[i]);
            };
        } else {
            for (var i = 0; i < product_name.length; i++) {
                product_name_chart.push(product_name[i]);
                sale_product_number_chart.push(sale_product_number[i]);
            };
        }
    }).done(function() {
        getchart(product_name_chart, sale_product_number_chart);
        var url = '?&begin=' + begin + '&end=' + end + '&prov=' + prov + '&city=' + city + '&dist=' + dist;
        // $("#order_downloads_down a").attr('href','/order/download/' + url);
        // $("#order_downloads_up a").attr('href','/order/download/' + url);
        var total = product_name.length;
        var page = Math.ceil(total / 10);
        $("#xsm_data").empty();
        pagination(page);
        if (total == 0) {

        } else {
            $("#table_page").text('共' + page + '页第' + 1 + '页');
        }

        if (total > 10) {
            for (var i = 0; i < 10; i++) {
                st = '<tr><td>' + (i + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] +
                    '</td><td>' + sale_product_member[i] + '</td><td>' + sale_product_cash[i] + '</td></tr>';
                $("#xsm_data").append(st);
            }
        } else if ((total > 0) && (total < 11)) {
            for (var i = 0; i < total; i++) {
                st = '<tr><td>' + (i + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] +
                    '</td><td>' + sale_product_member[i] + '</td><td>' + sale_product_cash[i] + '</td></tr>';
                $("#xsm_data").append(st);
            }
        } else {

        }


        $('#search_pagination').on('click', 'li', function() {
            var temp = $('#search_pagination li.active').text();
            var curpage = $(this).text();
            if (curpage == '上一页') {
                if (parseInt(temp) == 1) {

                } else {
                    $("#table_page").text('共' + parseInt(page) + '页第' + (parseInt(temp) - 1) + '页');
                    // $(this).siblings().remove();
                    // $(this).remove();
                    $('#search_pagination').children('li').remove();
                    clickpagination(parseInt(temp) - 1, page);
                    $("#xsm_data").empty();
                    for (var i = (parseInt(temp) - 2) * 10; i < ((parseInt(temp) - 1) * 10); i++) {
                        st = '<tr><td>' + (i + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] +
                            '</td><td>' + sale_product_member[i] + '</td><td>' + sale_product_cash[i] + '</td></tr>';
                        $("#xsm_data").append(st);
                    }
                }
            } else if (curpage == '下一页') {
                $("#table_page").text('共' + parseInt(page) + '页第' + (parseInt(temp) + 1) + '页');
                // $(this).siblings().remove();
                // $(this).remove();
                $('#search_pagination').children('li').remove();
                clickpagination(parseInt(temp) + 1, page);
                $("#xsm_data").empty();
                for (var i = (parseInt(temp) * 10); i < ((parseInt(temp) + 1) * 10); i++) {
                    st = '<tr><td>' + (i + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] +
                        '</td><td>' + sale_product_member[i] + '</td><td>' + sale_product_cash[i] + '</td></tr>';
                    $("#xsm_data").append(st);
                }
            } else {
                $("#table_page").text('共' + parseInt(page) + '页第' + (parseInt(curpage)) + '页');
                // $(this).siblings().remove();
                // $(this).remove();
                $('#search_pagination').children('li').remove();
                clickpagination(parseInt(curpage), page);
                $("#xsm_data").empty();
                if (total < (parseInt(curpage) * 10)) {
                    for (var i = (parseInt(curpage) - 1) * 10; i < total; i++) {
                        st = '<tr><td>' + (i + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] +
                            '</td><td>' + sale_product_member[i] + '</td><td>' + sale_product_cash[i] + '</td></tr>';
                        $("#xsm_data").append(st);
                    }
                } else {
                    for (var i = (parseInt(curpage) - 1) * 10; i < (parseInt(curpage) * 10); i++) {
                        st = '<tr><td>' + (i + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] +
                            '</td><td>' + sale_product_member[i] + '</td><td>' + sale_product_cash[i] + '</td></tr>';
                        $("#xsm_data").append(st);
                    }
                }
            }
            return false;
        });
    });
};
