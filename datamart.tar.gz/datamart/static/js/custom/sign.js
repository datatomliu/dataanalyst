$(document).ready(function() {
    $('.applyBtn').click(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
});


$(document).ready(function() {
    var startdate = moment().format("YYYY/MM/DD");
    $('#xsm_datersange').text(startdate + ' - ' + startdate);
    getdata(startdate, startdate, '全部', '', '');
    // alert(parseInt(Date.parse(startdate)-Date.parse(startdate))/(1000*60*60*24));
});

$(document).ready(function() {
    $('#xsm_range_filter').on('click', 'li', function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        // alert(moment(Date.parse('2016-01-03')).add('days',2).format('YYYY/MM/DD'));
        // alert(parseInt(Date.parse(end)-Date.parse(begin))/(1000*60*60*24));
        getdata(begin, end, prov, city, dist);
    });
});



$(document).ready(function() {
    $('.prov').change(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
    $('.city').change(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        var dist = $(".dist").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
    $('.dist').change(function() {
        $('#search_pagination').children('li').remove();
        var begin = $('.daterangepicker_start_input input').val();
        var end = $('.daterangepicker_end_input input').val();
        var dist = $(".dist").find("option:selected").text();
        var prov = $(".prov").find("option:selected").text();
        var city = $(".city").find("option:selected").text();
        getdata(begin, end, prov, city, dist);
    });
});

function clickpagination(curpage, totalpage) {
    if (totalpage > 10) {
        if (curpage > 6) {
            if (curpage == totalpage) {
                $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
                for (var i = (curpage - 9); i < (totalpage + 1); i++) {
                    $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
                }
                $('#search_pagination li:eq(' + 10 + ')').addClass('active');
            } else if (curpage > (totalpage - 5)) {
                $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
                for (var i = (totalpage - 9); i < (totalpage + 1); i++) {
                    $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
                }
                $('#search_pagination li:eq(' + (10 - totalpage + curpage) + ')').addClass('active');
            } else {
                $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
                for (var i = (curpage - 5); i < (curpage + 5); i++) {
                    $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
                }
                $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
                $('#search_pagination li:eq(' + 6 + ')').addClass('active');
            }
        } else {
            $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
            for (var i = 1; i < 11; i++) {
                $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
            }
            $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
            $('#search_pagination li:eq(' + curpage + ')').addClass('active');

        }
    } else if ((totalpage > 1) && (totalpage < 11)) {
        if (curpage == totalpage) {
            $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
            for (var i = 1; i < (totalpage + 1); i++) {
                $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
            }
            $('#search_pagination li:eq(' + curpage + ')').addClass('active');
        } else {
            $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
            for (var i = 1; i < (totalpage + 1); i++) {
                $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
            }
            $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
            $('#search_pagination li:eq(' + curpage + ')').addClass('active');
        }
    } else {
        $('#search_pagination').append("<li><a href='#'>" + 1 + "</a></li>");
        $('#search_pagination li:eq(' + 0 + ')').addClass('active');
    }
};

function pagination(page) {
    if (page == 1) {
        $('#search_pagination').append("<li><a href='#'>" + 1 + "</a></li>");
        $('#search_pagination li:eq(' + 0 + ')').addClass('active');
    } else if (page > 10) {
        $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
        for (var i = 1; i < 11; i++) {
            $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
        }
        $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
        $('#search_pagination li:eq(' + 1 + ')').addClass('active');
    } else if ((page > 1) && (page < 11)) {
        $('#search_pagination').append("<li><a href='#'><i class='fa-angle-left'></i>上一页</a></li>");
        for (var i = 1; i < (page + 1); i++) {
            $('#search_pagination').append("<li><a href='#'>" + i + "</a></li>");
        }
        $('#search_pagination').append("<li><a href='#'>下一页<i class='fa-angle-right'></i></a></li>");
        $('#search_pagination li:eq(' + 1 + ')').addClass('active');
    }

};

// var data1 = [3, 4, 3, 9, 4, 10, 12];
// var data2 = [1, 3, 4, 3, 3, 5, 4];

function getchart(cate, data1, data2) {
    $('#linechart').highcharts({
        chart: {
            type: 'areaspline'
        },
        title: {
            text: false
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            x: 150,
            y: 100,
            floating: true,
            borderWidth: 1,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        xAxis: {
            categories: cate,
        },
        yAxis: {
            title: {
                text: null
            }
        },
        tooltip: {
            shared: true,
            // valueSuffix: ''
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: [{
            name: '新注册用户数',
            data: data1
        }, {
            name: '累计注册用户数',
            data: data2
        }]
    });
}

function getdata(begin, end, prov, city, dist) {
    var login_date_chart = new Array();
    var sign_new_chart = new Array();
    var sign_total_chart = new Array();

    var login_date = new Array();
    var sign_new = new Array();
    var sign_total = new Array();

    var tempdate = parseInt(Date.parse(end)-Date.parse(begin))/(1000*60*60*24);
    for (var i = 0; i < tempdate + 1; i++) {
        login_date_chart.push(moment(Date.parse(begin)).add('days', i).format('YYYY/MM/DD'));
        sign_new_chart.push(0);
        sign_total_chart.push(0);
    }

    $.getJSON("/signapi/", {
        'begin': begin,
        'end': end,
        'prov': prov,
        'city': city,
        'dist': dist
    }, function(data) {
        for (var i = 0; i < data.fields.length; i++) {
            var temp = $.inArray(moment(Date.parse(data.fields[i].login_date)).format('YYYY/MM/DD'), login_date_chart);
            if (temp > -1) {
                login_date_chart[temp] = data.fields[i].login_date;
                sign_new_chart[temp] = parseInt(data.fields[i].sign_new);
                sign_total_chart[temp] = parseInt(data.fields[i].sign_total);
            } 
        };

        for (var i =0; i< login_date_chart.length ; i++) {
            if((sign_total_chart[i]==0)&(i>0)){
                var j = i;
                sign_total_chart[i] = sign_total_chart[j-1];
            }
        };

        for (var i = login_date_chart.length - 1; i >= 0; i--) {
            login_date.push(login_date_chart[i]);
            sign_new.push(sign_new_chart[i]);
            if((sign_total_chart[i]==0)&(i>0)){
                sign_total_chart[i] = sign_total_chart[i-1];
            }
            sign_total.push(sign_total_chart[i]);
        };
    }).done(function() {
        getchart(login_date_chart, sign_new_chart, sign_total_chart);
        var url = '?&begin=' + begin + '&end=' + end + '&prov=' + prov + '&city=' + city + '&dist=' + dist;
        $("#order_downloads_down a").attr('href', '/order/download/' + url);
        $("#order_downloads_up a").attr('href', '/order/download/' + url);
        var total = login_date.length;
        var page = Math.ceil(total / 10);
        $("#xsm_data").empty();
        pagination(page);
        if (total == 0) {

        } else {
            $("#table_page").text('共' + page + '页第' + 1 + '页');
        }

        if (total > 10) {
            for (var i = 0; i < 10; i++) {
                st = '<tr><td>' + (i + 1) + '</td><td>' + login_date[i] + '</td><td>' + sign_new[i] + '</td><td>' + sign_total[i] +
                     '</td></tr>'
                $("#xsm_data").append(st);
            }
        } else if ((total > 0) && (total < 11)) {
            for (var i = 0; i < total; i++) {
                st = '<tr><td>' + (i + 1) + '</td><td>' + login_date[i] + '</td><td>' + sign_new[i] + '</td><td>' + sign_total[i] +
                     '</td></tr>'
                $("#xsm_data").append(st);
            }
        } else {

        }


        $('#search_pagination').on('click', 'li', function() {
            var temp = $('#search_pagination li.active').text();
            var curpage = $(this).text();
            if (curpage == '上一页') {
                if (parseInt(temp) == 1) {

                } else {
                    $("#table_page").text('共' + parseInt(page) + '页第' + (parseInt(temp) - 1) + '页');
                    // $(this).siblings().remove();
                    // $(this).remove();
                    $('#search_pagination').children('li').remove();
                    clickpagination(parseInt(temp) - 1, page);
                    $("#xsm_data").empty();
                    for (var i = (parseInt(temp) - 2) * 10; i < ((parseInt(temp) - 1) * 10); i++) {
                        st = '<tr><td>' + (i + 1) + '</td><td>' + login_date[i] + '</td><td>' + sign_new[i] + '</td><td>' + sign_total[i] +
                     '</td></tr>'
                        $("#xsm_data").append(st);
                    }
                }
            } else if (curpage == '下一页') {
                $("#table_page").text('共' + parseInt(page) + '页第' + (parseInt(temp) + 1) + '页');
                // $(this).siblings().remove();
                // $(this).remove();
                $('#search_pagination').children('li').remove();
                clickpagination(parseInt(temp) + 1, page);
                $("#xsm_data").empty();
                for (var i = (parseInt(temp) * 10); i < ((parseInt(temp) + 1) * 10); i++) {
                    st = '<tr><td>' + (i + 1) + '</td><td>' + login_date[i] + '</td><td>' + sign_new[i] + '</td><td>' + sign_total[i] +
                     '</td></tr>'
                    $("#xsm_data").append(st);
                }
            } else {
                $("#table_page").text('共' + parseInt(page) + '页第' + (parseInt(curpage)) + '页');
                // $(this).siblings().remove();
                // $(this).remove();
                $('#search_pagination').children('li').remove();
                clickpagination(parseInt(curpage), page);
                $("#xsm_data").empty();
                if (total < (parseInt(curpage) * 10)) {
                    for (var i = (parseInt(curpage) - 1) * 10; i < total; i++) {
                        st = '<tr><td>' + (i + 1) + '</td><td>' + login_date[i] + '</td><td>' + sign_new[i] + '</td><td>' + sign_total[i] +
                     '</td></tr>'
                        $("#xsm_data").append(st);
                    }
                } else {
                    for (var i = (parseInt(curpage) - 1) * 10; i < (parseInt(curpage) * 10); i++) {
                        st = '<tr><td>' + (i + 1) + '</td><td>' + login_date[i] + '</td><td>' + sign_new[i] + '</td><td>' + sign_total[i] +
                     '</td></tr>'
                        $("#xsm_data").append(st);
                    }
                }
            }
            return false;
        });
    });
};