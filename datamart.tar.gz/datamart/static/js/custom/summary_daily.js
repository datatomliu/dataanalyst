function get_sumarry_daily_report() {
    var city_name = new Array();
    var order_all_people = new Array();
    var sign_new = new Array();
    var sale_number = new Array();
    var sale_cash = new Array();
    var date_name = new Array();

    $.getJSON("/api/summary/daily/report/", function(data) {
        for (var i = 0; i < data.fields.length; i++) {
            city_name.push(data.fields[i].city_name);
            order_all_people.push(data.fields[i].order_all_people);
            sign_new.push(data.fields[i].sign_new);
            sale_cash.push(data.fields[i].sale_cash);
            sale_number.push(data.fields[i].sale_number);
            date_name.push(data.fields[i].date_name);
        };
    }).done(function() {
        $("#sign_new").empty();
        $("#order_all_people").empty();
        $("#sale_number").empty();
        $("#sale_cash").empty();
        for (var i = 0; i < city_name.length; i++) {
            sign_new_data = '<tr><td>' + (i + 1) + '</td><td>' + city_name[i] + '</td><td>' + sign_new[i] + '</td></tr>';
            order_all_people_data = '<tr><td>' + (i + 1) + '</td><td>' + city_name[i] + '</td><td>' + order_all_people[i] + '</td></tr>';
            sale_number_data = '<tr><td>' + (i + 1) + '</td><td>' + city_name[i] + '</td><td>' + sale_number[i] + '</td></tr>';
            sale_cash_data = '<tr><td>' + (i + 1) + '</td><td>' + city_name[i] + '</td><td>' + sale_cash[i] + '</td></tr>';
            $("#sign_new").append(sign_new_data);
            $("#order_all_people").append(order_all_people_data);
            $("#sale_number").append(sale_number_data);
            $("#sale_cash").append(sale_cash_data);
        };
    });
};


function sale_product_number() {
    var product_name = new Array();
    var city_name = new Array();
    var sale_product_number = new Array();

    $.getJSON("/api/summary/product/daily/", function(data) {
        for (var i = 0; i < data.fields.length; i++) {
            product_name.push(data.fields[i].product_name);
            city_name.push(data.fields[i].city_name);
            sale_product_number.push(data.fields[i].sale_product_number);
        };
    }).done(function() {
        $("#sale_product_number_hz").empty();
        $("#sale_product_number_jx").empty();
        $("#sale_product_number_wz").empty();
        $("#sale_product_number_nj").empty();
        $("#sale_product_number_sz").empty();
        $("#sale_product_number_zj").empty();
        $("#sale_product_number_cq").empty();
        $("#sale_product_number_ha").empty();
        var j = 0;
        var h = 0;
        var o = 0;
        var k = 0;
        var l = 0;
        var m = 0;
        var n = 0;
        var p = 0;
        for (var i = 0; i < product_name.length; i++) {
            if ((city_name[i] == '杭州市') && (j < 10)) {
                sale_product_number_hz = '<tr><td>' + (j + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_hz").append(sale_product_number_hz);
                j++;
            } else if ((city_name[i] == '嘉兴市') && (h < 10)) {
                sale_product_number_jx = '<tr><td>' + (h + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_jx").append(sale_product_number_jx);
                h++;
            } else if ((city_name[i] == '温州市') && (o < 10)) {
                sale_product_number_wz = '<tr><td>' + (o + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_wz").append(sale_product_number_wz);
                o++;
            } else if ((city_name[i] == '南京市') && (k < 10)) {
                sale_product_number_nj = '<tr><td>' + (k + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_nj").append(sale_product_number_nj);
                k++;
            } else if ((city_name[i] == '苏州市') && (l < 10)) {
                sale_product_number_sz = '<tr><td>' + (l + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_sz").append(sale_product_number_sz);
                l++;
            } else if ((city_name[i] == '镇江市') && (m < 10)) {
                sale_product_number_zj = '<tr><td>' + (m + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_zj").append(sale_product_number_zj);
                m++;
            } else if ((city_name[i] == '重庆市') && (n < 10)) {
                sale_product_number_cq = '<tr><td>' + (n + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_cq").append(sale_product_number_cq);
                n++;
            } else if ((city_name[i] == '淮安市') && (p < 10)) {
                sale_product_number_ha = '<tr><td>' + (p + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_ha").append(sale_product_number_ha);
                p++;
            } else if ((city_name[i] == '常州市') && (p < 10)) {
                sale_product_number_cz = '<tr><td>' + (p + 1) + '</td><td>' + product_name[i] + '</td><td>' + sale_product_number[i] + '</td></tr>';
                $("#sale_product_number_cz").append(sale_product_number_cz);
                p++;
            }
        };
    });
};

$(document).ready(function() {
    date_name = moment().subtract(1,'days').format('YYYY-MM-DD');
    $("#headtitle_name_top").html(date_name + "&nbsp;" + "相关业务指标数据");
    $("#headtitle_name_second").html(date_name + "&nbsp;" + "各地区商品热销TOP10榜");
    get_sumarry_daily_report();
    sale_product_number();
    $('#main_menu_summary_detail li:eq(' + 0 + ')').addClass('active');
});
