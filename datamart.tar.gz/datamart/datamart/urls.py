from django.conf.urls import patterns, include, url
from django.contrib import admin

urlpatterns = patterns('',
    url(r'^admin/', include(admin.site.urls)),
    url(r'^order/$', 'analyst.views.order', name='order'),
    url(r'^login/$', 'analyst.views.login', name='login'),
    url(r'^operation/order_api/', 'analyst.views.order_api', name='order_api'),
    url(r'^summary/daily/report/$', 'analyst.views.daily_summary', name='daily_summary'),
    url(r'^api/summary/daily/report/$', 'analyst.views.summary_daily_report_api', name='summary_daily_report_api'),
    url(r'^api/product/', 'analyst.views.product_api', name='product_api'),
    url(r'^api/product/daily/', 'analyst.views.product_daily_api', name='product_daily_api'),
    url(r'^member/daily/', 'analyst.views.daily_member', name='daily_member'),
    url(r'^api/member/daily/', 'analyst.views.member_daily_api', name='member_daily_api'),
    url(r'^product/daily/', 'analyst.views.daily_product', name='daily_product'),
    url(r'^api/product/daily/', 'analyst.views.product_daily_api', name='product_daily_api'),
    url(r'^api/summary/product/daily/', 'analyst.views.summary_product_daily_api', name='summary_product_daily_api'),
)
